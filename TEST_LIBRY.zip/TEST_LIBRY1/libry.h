#ifndef LIBRY_H
#define LIBRY_H

int power(int base, int exp);
int fact(int n);

#endif
